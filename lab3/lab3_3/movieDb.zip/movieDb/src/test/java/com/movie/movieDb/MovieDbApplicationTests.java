package com.movie.movieDb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
